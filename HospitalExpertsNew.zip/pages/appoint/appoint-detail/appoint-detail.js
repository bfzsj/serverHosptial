// pages/appoint/appoint-detail/appoint-detail.js
Page({
  data: {
    isShow: false,
    dateStr: '',
    doctorid:'',
    user_wx_id:'',
    year:'',
    month:'',
    day:'',
    time:'',
    unArr:[],
  },
  onLoad: function (options) {
    this.setData({
      doctorid: options.bh,
      user_wx_id: wx.getStorageSync('userOpenId').wx_open_id
    })
    console.log(this.data)
    let that=this
    //findOneAppointment
    wx.request({
      url: getApp().globalData.baseUrl + "findOneAppointment",
      method: "POST",
      data: {
        doctorid:this.data.doctorid,
        user_wx_id:this.data.user_wx_id
      },
      success: function (res) {
        console.log(res)
        that.setData({
          unArr:res.data
        })
      },

    })
  },
  _yybindchange: function (e) {
    let times = e.detail.date.split(".");
    let [year,month,day,time]=times;
    let that=this;
    this.setData({
      year:year,
      month:month,
      day:day,
      time:time
    })
    wx.request({
      url: getApp().globalData.baseUrl + "insertAppointment",
      method: "POST",
      data: that.data,
      success: function (res) {
        console.log(res)
        if(res.statusCode==200){
          wx.showToast({
            title: '预约成功',
            icon: 'success',
            duration: 1500,
            mask: false,
          })

          setTimeout(function () {
            wx.navigateBack({
              url: '../appoint',
            })
          }, 1500)
        }
      },

    })
    //insertAppointment
    
  },
  cellClick: function () {
    var isShow = true
    this.setData({
      isShow: isShow
    })
  }
})